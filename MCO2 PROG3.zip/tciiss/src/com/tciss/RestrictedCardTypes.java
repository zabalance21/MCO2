package com.tciss;

public interface RestrictedCardTypes {
	boolean isCardAllowed(Card card);
}
